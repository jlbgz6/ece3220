#include<stdio.h>
int main()
{
	int x=1309;
	int *p = NULL;
	printf("\n The value of x is = %d",x);
	printf("\n The pointer points to the value = %d",*p);
	return 1;
}
